#Desc: This program is to create a receipt for the St. John's Mariana & Yacht Club.
#Author: Keira Hancock
#Dates: Sept 26 - Oct 6




# Assign program constants. (ALL CAPS with _ between words.)


EVEN_NUM = 80.00             # dollars
ODD_NUM = 120.00             # dollars
ALT_MEMBER = 5.00            # dollars per alternate member

SITE_CLEAN = 50.00           # dollars per month
VIDEO_SURV = 35.00           # dollars per month

HST_RATE = 0.15              # percent

STANDARD_DUES = 75.00        # dollars per month
EXECUTIVE_DUES = 150.00      # dollars per month

PROCESSING_FEE = 59.99       # dollars per month
CANCELLATION_FEE = 0.6       # percent


print()
print()


# Gather user input.


Date = input("Enter the Current Date (YYYY-MM-DD): ")
SiteNum = input("Enter the Site Number (1-100): ")
SiteNum = int(SiteNum)
print()
MemName = input("Enter the Member Name: ")
MemAddress = input("Enter the Member Street Address: ")
MemCity = input("Enter the Member City: ")
MemProvince = input("Enter the Member Province (LL): ").upper()
MemPostalCode = input("Enter the Member Postal Code (L0L0L0): ").upper()
PhoneNum = input("Enter the Member Phone Number (0000000000): ")
CellNum = input("Enter the Member Cell Number(0000000000): ")
print()
MemType = input("Enter Membership Type (S for Standard, E for Executive): ").upper()
NumAltMem = input("Enter the Number of Alternate Members: ")
NumAltMem = int(NumAltMem)
print()
WeeklyClean = input("Add the Weekly Site Cleaning Option (Y/N): ").upper()
VideoSurv = input("Add the Video Surveillance Option (Y/N): ").upper()




#Perform required calculations for the receipt.


# Processing option for site cost based on even and odd numbers.
# The Modulus operator (%) returns the remainder.
RemSite = SiteNum % 2
if RemSite == 0:
    EvenOdd = EVEN_NUM
else:
    EvenOdd = ODD_NUM

                    
AltMemCost = ALT_MEMBER * NumAltMem

SiteCharge = EvenOdd + AltMemCost


# Processing option for weekly site cleaning.
CleanCost = 0.00
if WeeklyClean =="Y":
    CleanCost = SITE_CLEAN

# Processing option for video surveillance.
VideoSurvCost = 0.00
if VideoSurv =="Y":
    VideoSurvCost = VIDEO_SURV

ExtraCharge = CleanCost + VideoSurvCost


Subtotal = SiteCharge + ExtraCharge

HST = Subtotal * HST_RATE


TotalMonthlyCharge = Subtotal + HST

# Processing option for monthly dues based on standard or executive dues.
MonthlyDues = STANDARD_DUES
if MemType == "E":
    MonthlyDues = EXECUTIVE_DUES

TotalMonthlyFees = TotalMonthlyCharge + MonthlyDues

TotalYearlyFees = TotalMonthlyFees * 12


MonthlyPayment = (TotalYearlyFees + PROCESSING_FEE) /12


YearlySiteCharge = TotalMonthlyCharge * 12

CancellationFee = YearlySiteCharge * CANCELLATION_FEE



#Display the receipt for the receptionist and member.


print()
print()
print(f"      St.John's Marina & Yacht Club")
print(f"          Yearly Member Receipt")
print()
print(f"  ------------------------------------  ")
print()
print(f"   Client Name and Address:")
print()

print(f"   {MemName:<23s}") 
print(f"   {MemAddress:<23s}")
print(f"   {MemCity:<15s}, {MemProvince:<2s} {MemPostalCode:>6s}")
print()
print(f"   Phone: {PhoneNum:>10s} (H)")
print(f"          {CellNum:>10s} (C)")
print()

# Processing for if Standard or Executive is selected.
if MemType == "S":
    MemTypeName = "STANDARD"
elif MemType == "E":
    MemTypeName = "EXECUTIVE"
print(f"   Site #: {SiteNum:>3d} Member type: {MemTypeName:<9s}")

print()
print(f"   Alternate Members:              {NumAltMem:>2d}")

# Processing for if weekly cleaning option is yes or no.
if WeeklyClean == "Y":
    CleanOption = "YES"
elif WeeklyClean == "N":
    CleanOption = "NO"
print(f"   Weekly Site Cleaning:          {CleanOption:<3s}")

# Processing for if video surveillance option is yes or no.
if VideoSurv == "Y":
    VideoOption = "YES"
elif VideoSurv == "N":
    VideoOption = "NO"    
print(f"   Video Surveillance:            {VideoOption:<3s}")

print()

# Format the site charges to a dollar value.
# The formatted value is a string. Add Dsp to the end of the name to indicate it is a string to be printed.
SiteChargeDsp = "${:,.2f}".format(SiteCharge)
print(f"   Site Charges:            {SiteChargeDsp:>9s}")

# Format the extra charges to a dollar value.
ExtraChargeDsp = "${:,.2f}".format(ExtraCharge)
print(f"   Extra Charges:             {ExtraChargeDsp:>7s}")
print()
print(f"                            ---------")

# Format the subtotal to a dollar value.
SubtotalDsp = "${:,.2f}".format(Subtotal)
print(f"   Subtotal:                {SubtotalDsp:>9s}")

# Format the sales tax (HST) to a dollar value.
HSTDsp = "${:,.2f}".format(HST)
print(f"   Sales Tax (HST):           {HSTDsp:>7s}")
print()
print(f"                            ---------")

# Format the total monthly charges to a dollar value.
TotalMonthlyChargeDsp = "${:,.2f}".format(TotalMonthlyCharge)
print(f"   Total Monthly Charges:   {TotalMonthlyChargeDsp:>9s}")

# Format the monthly dues to a dollar Value.
MonthlyDuesDsp = "${:,.2f}".format(MonthlyDues)
print(f"   Monthly Dues:              {MonthlyDuesDsp:>7s}")
print()
print(f"                            ---------")

# Format the total monthly fees to a dollar value.
TotalMonthlyFeesDsp = "${:,.2f}".format(TotalMonthlyFees)
print(f"   Total Monthly Fees:      {TotalMonthlyFeesDsp:>9s}")

# Format the total yearly fees to a dollar value.
TotalYearlyFeesDsp = "${:,.2f}".format(TotalYearlyFees)
print(f"   Total Yearly Fees:      {TotalYearlyFeesDsp:>10s}")
print()

# Format the monthly payment to a dollar value.
MonthlyPaymentDsp = "${:,.2f}".format(MonthlyPayment)
print(f"   Monthly Payment:         {MonthlyPaymentDsp:>9s}")
print()
print(f"  ------------------------------------  ")
print()
print(f"   Issued: {Date:<10s}")
print(f"   HST Reg No: 549-33-5849-4720-9885")
print()

# Format the Cancellation Fee to a Dollar Value.
CancellationFeeDsp = "${:,.2f}".format(CancellationFee)
print(f"   Cancellation Fee:        {CancellationFeeDsp:>9s}")
print()
print()