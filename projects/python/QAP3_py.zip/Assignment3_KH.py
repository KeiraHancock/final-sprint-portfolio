#Desc: This program is to create a invoice/receipt for Honset Harry Car Sales. This will allow the user to decide on payment options.
#Author: Keira Hancock
#Dates: Oct 9 - 18, 2024



# Define required libraries.

import datetime



# Assign program constants. (ALL CAPS with _ between words.)


LICENSE_FEE_STANDARD = 75.00       # dollars
LICENSE_FEE_OVER = 165.00          # dollars

TRANSFER_FEE = 0.01                # percent
LUXURY_TAX = 0.016                 # percent

HST_RATE = 0.15                    # percent

FINANCING_FEE = 39.99              # dollars

CUR_DATE = datetime.datetime.now() # current date
DAYS_AFTER = 30                    # days


print ()
print ()



# Define program functions.


# Function to generate receipt ID
def GenerateReceiptID(FirstName, LastName, PhoneNum, PlateNum):
    Initials = FirstName[0].upper() + LastName[0].upper()
    PlateLastDigits = PlateNum[-3:]
    PhoneLastDigits = PhoneNum[-4:]
    return f"{Initials}-{PlateLastDigits}-{PhoneLastDigits}"



# Main program starts here.



while True:



    # Gather and process user inputs.



    allowed_char1 = set("ABCDEFGHIJKLMONPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz.-'")
    # Used with strings to limit the characters that can be entered.

    while True:
        FirstName = input("Enter the Customer First Name (END to quit): ").title()

        if FirstName.upper() == "END":
            exit()

    
        if FirstName == "":
            print()
            print(" Data Entry Error - Customer First Name must be entered...")
            print()
        elif set(FirstName).issubset(allowed_char1) == False:
            print()
            print(" Data Entry Error - Customer First Name contains invalid characters...")
            print()
        else:
            break



    while True:
        LastName = input("Enter the Customer Last Name: ").title()
        
        if LastName == "":
            print()
            print(" Data Entry Error - Customer Last Name must be entered...")
            print()
        elif set(LastName).issubset(allowed_char1) == False:
            print()
            print(" Data Entry Error - Customer Last Name contains invalid characters...")
            print()
        else:
            break



    allowed_char2 = set("1234567890")

    while True:
        PhoneNum = input("Enter the Customer Phone Number (0000000000): ")
 
        if PhoneNum == "":
            print()
            print("   Data Entry Error - Customer Phone Number must be entered ...")
            print()
        elif len(PhoneNum) != 10:
    # The len() function counts the number of characters in the string.
            print()
            print("   Data Entry Error - Customer Phone Number must be 10 digits ...")
            print()
        elif set(PhoneNum).issubset(allowed_char2) == False:
            print()
            print("   Data Entry Error - Customer Phone Number contains invalid characters ...")
            print()
        else:
            break



    allowed_char3 = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890")

    while True:
        PlateNum = input("Enter the Plate Number: ").upper()

        if PlateNum == "":
            print()
            print("   Data Entry Error - Plate Number must be entered ...")
            print()
        elif len(PlateNum) != 6:
            print()
            print("   Data Entry Error - Plate Number must be 6 characters ...")
            print()
        elif set(PlateNum).issubset(allowed_char3) == False:
            print()
            print("   Data Entry Error - Plate Number contains invalid characters / capitalization ...")
            print()
        else:
            break



    while True:
        CarMake = input("Enter the Car Make (ie. Toyota): ").title()

        if CarMake == "":
            print()
            print("   Data Entry Error - Car Make must be entered ...")
            print()
        else:
            break



    while True:
        CarModel = input("Enter the Car Model (ie. Corolla): ").title()

        if CarModel == "":
            print()
            print("   Data Entry Error - Car Model must be entered ...")
            print()
        else:
            break



    while True:
        CarYear = input("Enter the Year of the Car (ie. 2018): ")

        if CarYear == "":
            print()
            print("   Data Entry Error - Year of the Car must be entered ...")
            print()
        elif len(CarYear) != 4:
            print()
            print("   Data Entry Error - Year of the Car must be 4 digits ...")
            print()
        elif set(CarYear).issubset(allowed_char2) == False:
            print()
            print("   Data Entry Error - Year of the Car contains invalid characters ...")
            print()
        else:
            break



    allowed_char4 = set("1234567890.")

    while True:
        SellPrice = input("Enter the Selling Price: $")
        SellPrice = int(SellPrice)

        if SellPrice == "":
            print()
            print("   Data Entry Error - Selling Price must be entered ...")
            print()
        elif SellPrice > 50000.00:
            print()
            print("   Data Entry Error - Selling Price cannot exceed $50,000.00 ...")
            print()
        elif set(str(SellPrice)).issubset(allowed_char4) == False:
            print()
            print("   Data Entry Error - Selling Price contains invalid characters ...")
            print()
        else:
            break




    while True:
        TradeIn = input("Enter the Trade In Price: $")
        TradeIn = float(TradeIn)

        if TradeIn == "":
            print()
            print("   Data Entry Error - Trade In Price must be entered ...")
            print()
        elif TradeIn > SellPrice:
            print()
            print("   Data Entry Error - Trade In Price cannot exceed Selling Price ...")
            print()
        elif set(str(TradeIn)).issubset(allowed_char4) == False:
            print()
            print("   Data Entry Error - Trade In Price contains invalid characters ...")
            print()
        else:
            break



    while True:
        SalesPerson = input("Enter the Salespersons Name: ").title()

        if SalesPerson == "":
            print()
            print("   Data Entry Error - Salespersons Name must be entered ...")
            print()
        elif set(SalesPerson).issubset(allowed_char1) == False:
            print()
            print("   Data Entry Error - Salespersons Name contains invalid characters ...")
            print()
        else:
            break



    # Perform the required calculations for the invoice/receipt.


    # Converting sell price and trade in price from str to int.
    SellPrice = int(SellPrice)
    TradeIn = int(TradeIn)


    # Calculate the price after trade.
    AfterTrade = SellPrice - TradeIn


    # Calculate the license fee.
    # Processing for standard or over license fee.
    LicenseFee = LICENSE_FEE_STANDARD
    if SellPrice < 15000.00:
        LicenseFee = LICENSE_FEE_OVER


    # Calculate the transfer fee.
    TransferFee = SellPrice * TRANSFER_FEE


    # Processing option for luxury tax.
    TotalTransferFee = TransferFee
    if SellPrice < 20000.00:
        TotalTransferFee = TransferFee + (SellPrice * LUXURY_TAX)


    # Calculate the subtotal.
    Subtotal = AfterTrade + LicenseFee + TotalTransferFee


    # Calculate the taxes (HST).
    HST = Subtotal * HST_RATE


    # Calculate the total sales price.
    TotalSalesPrice = Subtotal + HST


    # Calculate the first payment date.
    CurDatePlus30 = CUR_DATE + datetime.timedelta(days = DAYS_AFTER)



    # Generate receipt ID.
    ReceiptID = GenerateReceiptID(FirstName, LastName, PhoneNum, PlateNum)



    # Display the invoice/receipt.


    print()
    print()
    print()
    print()


    # Format the current date.
    print(f"Honest Harry Car Sales                       Invoice Date:    {CUR_DATE.strftime("%b %d, %Y")}")


    print(f"Used Car Sale and Receipt                    Receipt No:       {ReceiptID}")


    print()


    # Format the sale price to a dollar value.
    # The formatted value is a string. Add Dsp to the end of the name to indicate it is a string to be printed.
    SellPriceDsp = "${:,.2f}".format(SellPrice)
    print(f"                                       Sale Price:              {SellPriceDsp:>7s}")


    # Format the trade allowance to a dollar value.
    TradeInDsp = "${:,.2f}".format(TradeIn)
    print(f"Sold to:                               Trade Allowance:         {TradeInDsp:>7s}")


    print(f"                                       -----------------------------------")


    # Format first name and last name.
    # Format the price after trade to a dollar value.
    AfterTradeDsp = "${:,.2f}".format(AfterTrade)
    print(f"     {FirstName[0]}. {LastName:<26s}     Price after Trade:       {AfterTradeDsp:>7s}")


    # Format the phone number.
    # Format license fee to a dollar value.
    LicenseFeeDsp = "${:,.2f}".format(LicenseFee)
    print(f"     ({PhoneNum[:3]}) {PhoneNum[3:6]}-{PhoneNum[6:10]}                    License Fee:            {LicenseFeeDsp:>7s}")


    # Format transfer fee to a dollar value.
    TotalTransferFeeDsp = "${:,.2f}".format(TotalTransferFee)
    print(f"                                       Transfer Fee:            {TotalTransferFeeDsp:>7s}")


    print(f"                                       -----------------------------------")


    # Format subtotal to a dollar value.
    SubtotalDsp = "${:,.2f}".format(Subtotal)
    print(f"Car Details:                           Subtotal:                {SubtotalDsp:>7s}")


    # Format sales tax (HST) to a dollar value.
    HSTDsp = "${:,.2f}".format(HST)
    print(f"                                       HST:                     {HSTDsp:>7s}")


    # Format car year, make, and model.
    print(f"     {CarYear:>4s} {CarMake:<13s} {CarModel:<10s}     -----------------------------------")


    # Format total sales price to a dollar value.
    TotalSalesPriceDsp = "${:,.2f}".format(TotalSalesPrice)
    print(f"                                       Total sales price:       {TotalSalesPriceDsp:>7s}")


    print()


    print(f"--------------------------------------------------------------------------")


    print()


    print(f"                               Fincancing    Total        Monthly")


    print(f"     # Years    # Payments        Fee        Price        Payment")


    print(f"     ------------------------------------------------------------")


    # Loop for payment schedule.
    for Years in range (1, 5):

        NumPayments = Years * 12

        FinanceFee = Years * FINANCING_FEE

        TotalPrice = TotalSalesPrice + FinanceFee

        MonthlyPayment = TotalPrice / NumPayments

    # Format neccessary payment schedule values.
        FinanceFeeDsp = "${:,.2f}".format(FinanceFee)
        TotalPriceDsp = "${:,.2f}".format(TotalPrice)
        MonthlyPaymentDsp = "${:,.2f}".format(MonthlyPayment)

        print(f"        {Years:>1d}           {NumPayments:>2d}          {FinanceFeeDsp:>7s}     {TotalPriceDsp:>9s}   {MonthlyPaymentDsp:>8s}")


    print(f"     ------------------------------------------------------------")


    # Format the current date and first payment date.
    print(f"     Invoice date: {CUR_DATE.strftime("%d-%b-%y").upper()}        First payment date: {CurDatePlus30.strftime("%d-%b-%y").upper()}")


    print()


    print(f"--------------------------------------------------------------------------")

    print(f"                   Best used cars at the best prices!")


    print()
    print()
    print()
    print()