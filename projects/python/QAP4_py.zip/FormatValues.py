from datetime import datetime, timedelta


def FDollar2(DollarValue):
    # Ensure DollarValue is a float for proper formatting
    DollarValue = float(DollarValue)  # Convert to float if it's a string
    DollarValueStr = "${:,.2f}".format(DollarValue)
    return DollarValueStr


def FDollar0(DollarValue):
    # Function will accept a value and format it to $#,###.##.

    DollarValueStr = "${:,.0f}".format(DollarValue)

    return DollarValueStr


def FComma2(Value):
    # Function will accept a value and format it to $#,###.##.

    ValueStr = "{:,.2f}".format(Value)

    return ValueStr


def FComma0(Value):
    # Function will accept a value and format it to $#,###.##.

    ValueStr = "{:,.0f}".format(Value)

    return ValueStr


def FNumber0(Value):
    # Function will accept a value and format it to $#,###.##.

    ValueStr = "{:.0f}".format(Value)

    return ValueStr


def FNumber1(Value):
    # Function will accept a value and format it to $#,###.##.

    ValueStr = "{:.1f}".format(Value)

    return ValueStr


def FNumber2(Value):
    # Function will accept a value and format it to $#,###.##.

    ValueStr = "{:.2f}".format(Value)

    return ValueStr


def FDateS(DateValue):
    # If DateValue is a string, convert it to a datetime object
    if isinstance(DateValue, str):
        try:
            DateValue = datetime.strptime(DateValue, "%Y-%m-%d")  # Adjust the format if necessary
        except ValueError:
            return "Invalid Date Format"  # Return error if the date format is incorrect
    
    # Now that DateValue is a datetime object (or already was), format it to yyyy-mm-dd
    DateValueStr = DateValue.strftime("%Y-%m-%d")
    
    return DateValueStr


def FDateM(DateValue):
    # Function will accept a value and format it to dd-Mon-yy.

    DateValueStr = DateValue.strftime("%d-%b-%y")

    return DateValueStr


def FDateL(DateValue):
    # Function will accept a value and format it to Day, Month dd, yyyy.

    DateValueStr = DateValue.strftime("%A, %B %d, %Y")

    return DateValueStr