# Description: This program is to enter and calculate new insurance policy information for its customers, then display all input and calculated values on a receipt, including previous claims.
# Author: Keira Hancock
# Date(s): November 15 - 29, 2024


# Define required libraries.

from datetime import datetime, timedelta
import FormatValues as FV


# Define program constants.

BASIC_RATE = 869.00 # Dollars
DISCOUNT_RATE = 0.25 # Percent
EXTRA_LIABILITY = 130.00 # Dollars Per Car
GLASS_COVERAGE = 86.00 # Dollars Per Car
LOANER_CAR = 58.00 # Dollars Per Car
HST_RATE = 0.15 # Percent
PROCESSING_FEE = 39.99 # Dollars
PROV_LST = ["NL", "PE", "NS", "NB", "QC", "ON", "MB", "SK", "AB", "BC", "YT", "NT", "NU"]
PAY_OPTION_LST = ["Full", "Monthly", "Down Pay"]
CLAIM_NUM_LST = [10101, 10102, 10103]
CLAIM_DATE_LST = ["2024-01-15", "2024-02-20", "2024-03-10"]
CLAIM_AMT_LST = [12345.67, 8901.23, 45678.90]
OPTION_LST = ["Y", "N"]


# Define program functions.

# Calculate the first day of the next month.
def FirstDay(date):
    # If the next month is January.
    if date.month == 12:
        return datetime(date.year + 1, 1, 1)
    else:
        # Otherwise, next month.
        return datetime(date.year, date.month + 1, 1)
# Calculate the Extra Costs (Liability, Glass Coverage, Loaner Car) and Process options.
def ExtraCosts(NumCars, ExtraLiability, GlassCoverage, LoanerCar):
    # Extra Liability Cost.
    if ExtraLiability == "Y":
        LiabilityCost = EXTRA_LIABILITY * NumCars
    else:
        LiabilityCost = 0
    # Glass Coverage Cost.
    if GlassCoverage == "Y":
        GlassCovCost = GLASS_COVERAGE * NumCars
    else:
        GlassCovCost = 0
    # Loaner Car Cost.
    if LoanerCar == "Y":
        LoanerCost = LOANER_CAR * NumCars
    else:
        LoanerCost = 0
        # Return the Costs.
    return LiabilityCost, GlassCovCost, LoanerCost
# Calculate and Process the Payment Option.
def PayOption(Payment, TotalCost, DownPayment):
    # If user enters Down Payment Option.
    if Payment == "Down Pay":
        MonthlyPay = ((TotalCost - DownPayment) + PROCESSING_FEE) / 8
    # If user enters Monthly with no Down Payment Option.
    else:
        MonthlyPay = (TotalCost + PROCESSING_FEE) / 8
    # Return the Cost.
    return MonthlyPay


# Main program starts here.
while True:


    # Gather user inputs.
    print()
    print()
    print()
    # Validate that the First Name is entered.
    while True:
        # Convert the First Name to input Title Case.
        FirstName = input(" Enter the Customer's First Name: ").title()
        if FirstName == "":
            print()
            print("   Data Entry Error - Customer First Name must be entered...")
            print()
        else:
            break
    # Validate that the Last Name is entered.
    while True:
        # Convert the Last Name input to Title Case.
        LastName = input(" Enter the Customer's Last Name: ").title()
        if LastName == "":
            print()
            print("   Data Entry Error - Customer Last Name must be entered...")
            print()
        else:
            break
    # Validate that the Address is entered.
    while True:
        Address = input(" Enter the Address: ").title()
        if Address == "":
            print()
            print("   Data Entry Error - Address must be entered...")
            print()
        else:
            break
    # Validate that the City is entered.
    while True:
        # Convert the City input to Title Case.
        City = input(" Enter the City: ").title()
        if City == "":
            print()
            print("   Data Entry Error - City must be entered...")
            print()
        else:
            break
    # Validate that the Province is entered and contains 2 characters.
    while True:
        # Convert the Province input to Upper Case.
        Province = input(" Enter the Province (XX): ").upper()
        if Province == "":
            print()
            print("   Data Entry Error - Province must be entered...")
            print()
        elif len(Province) != 2:
            print()
            print("   Data Entry Error - Province must be 2 characters only...")
            print()
        # Validate the Province using a List.
        elif Province not in PROV_LST:
            print()
            print("   Data Entry Error - Province is invalid...")
            print()
        else:
            break
    # Validate that the Postal Code is entered.
    while True:
        PostalCode = input(" Enter the Postal Code: ").upper()
        if PostalCode == "":
            print()
            print("   Data Entry Error - Postal Code must be entered...")
            print()
        else:
            break
    # Set Allowed Characters for the Phone Number input.
    allowed_char1 = set("1234567890")
    # Validate that the Phone Number is entered, is 10 digits, and contains only numbers.
    while True:
        PhoneNum = input(" Enter the Phone Number: ")
        if PhoneNum == "":
            print()
            print("   Data Entry Error - Phone Number must be entered...")
            print()
        elif len(PhoneNum) != 10:
        # The len() function counts the number of characters in the string.
            print()
            print("   Data Entry Error - Customer Phone Number must be 10 digits ...")
            print()
        elif set(PhoneNum).issubset(allowed_char1) == False:
            print()
            print("   Data Entry Error - Customer Phone Number contains invalid characters ...")
            print()
        else:
            break
    print()
    # Validate that the Number of Cars is entered and contains only numbers.
    while True:
        NumCars = input(" Enter the Number of Cars being Insured: ")
        if NumCars == "":
            print()
            print("   Data Entry Error - Number of Cars must be entered...")
            print()
        elif set(NumCars).issubset(allowed_char1) == False:
            print()
            print("   Data Entry Error - Number of Cars contains invalid characters...")
            print()
        else:
            break
    # Convert the Number of Cars to an Integer.
    NumCars = int(NumCars)
    print()
    # Validate that the Extra Liability option is entered.
    while True:
        # Convert the Extra Liability option input to Upper Case
        ExtraLiability = input(" Enter Option for Extra Liability up to $1,000,000 (Y/N): ").upper()
        if ExtraLiability == "":
            print()
            print("   Data Entry Error - Extra Liability Option must be entered...")
            print()
        elif ExtraLiability not in OPTION_LST:
            print()
            print("   Data Entry Error - Option entered is invalid. must be Y or N...")
            print()
        else:
            break
    # Validate that the Glass Coverage option is entered.
    while True:
        # Convert the Glass Coverage option input to Upper Case.
        GlassCoverage = input(" Enter Option for Glass Coverage (Y?N): ").upper()
        if GlassCoverage == "":
            print()
            print("   Data Entry Error - Glass Coverage Option must be entered...")
            print()
        elif GlassCoverage not in OPTION_LST:
            print()
            print("   Data Entry Error - Option entered is invalid. must be Y or N...")
            print()
        else:
            break
    # Validate that the Loaner Car option is entered.
    while True:
        # Convert the Loaner Car option input to Upper Case.
        LoanerCar = input(" Enter Option for Loaner Car (Y/N): ").upper()
        if LoanerCar == "":
            print()
            print("   Data Entry Error - Loaner Car Option must be entered...")
            print()
        elif LoanerCar not in OPTION_LST:
            print()
            print("   Data Entry Error - Option entered is invalid. must be Y or N...")
            print()
        else:
            break
    print()
    # Validate that the Payment option is entered.
    while True:
        # Convert the Payment option input to Title Case.
        Payment = input(" Enter Choice of Payment Option (Full or Monthly or Down Pay): ").title()
        if Payment == "":
            print()
            print("   Data Entry Error - Payment Option must be entered...")
            print()
        # Validate Payment Option using a List.
        elif Payment not in PAY_OPTION_LST:
            print()
            print("   Data Entry Error - Payment Option is invalid...")
            print()
        # Input for Down Pay Amount if user inputs Down Pay.
        elif Payment == "Down Pay":
            print()
            DownPayment = input("   Enter Amount of Down Payment: ")
            break
        else:
            break
    # Convert Down Payment to an Integer.
    DownPayment = int(DownPayment)
    print()
    # Prompt for entering Previous Claim information.
    print(" Please Enter the Claim Number, Claim Date, and Claim Amount of all previous claims for the customer.")
    print()
    # Loop for entering Previous Claim information.
    while True:
        # Validate that the Claim Number is entered.
        while True:
            ClaimNum = input(" Enter the Previous Claim Number: ")
            if ClaimNum == "":
                print()
                print("   Data Entry Error - Previous Claim Number must be entered...")
                print()
            else:
                break
        # Convert Claim Number to an Integer.
        ClaimNum = int(ClaimNum)
        # Stores the input value to the end of a List.
        CLAIM_NUM_LST.append(ClaimNum)
        # Validate that the Claim Date is entered.
        while True:
            ClaimDate = input(" Enter the Previous Claim Date (YYYY-MM-DD): ")
            if ClaimDate == "":
                print()
                print("   Data Entry Error - Previous Clain Date must be entered...")
                print()
            else:
                break
        # Stores the input value to the end of a List.
        CLAIM_DATE_LST.append(ClaimDate)
        # Validate that the Claim Amount is entered.
        while True:
            ClaimAmt = input(" Enter the Previous Claim Amount: ")
            if ClaimAmt == "":
                print()
                print("   Data Entry Error - Previous Claim Amount must be entered...")
                print()
            else:
                break
        # Stores the input value to the end of a List.
        CLAIM_AMT_LST.append(ClaimAmt)
        print()
        # Option for ending the Previous Claim Loop.
        ClaimRepeat = input(" Would you like to enter another Previous Claim? (Y/N): ").upper()
        print()
        if ClaimRepeat == "N":
            break


    # Perform required calculations.

    # Calculation for the Insurance premiums based on the number of cars.
    DiscountApplied = BASIC_RATE * DISCOUNT_RATE
    if NumCars == 1:
        InsurancePrem = BASIC_RATE
    else:
        InsurancePrem = BASIC_RATE + ((NumCars - 1) * DiscountApplied)
    # Get Extra Costs from Function.
    LiabilityCost, GlassCovCost, LoanerCost = ExtraCosts(NumCars, ExtraLiability, GlassCoverage, LoanerCar)
    # Calculation for Total Extra Costs.
    TotalExtra = LiabilityCost + GlassCovCost + LoanerCost
    # Calculation for Total Insurance Premium.
    TotalInsurancePremium = InsurancePrem + TotalExtra
    # Calculation for HST.
    HST = TotalInsurancePremium * HST_RATE
    # Calculation for the Total Cost - If user enters Full Payment Option, this cost will be displayed.
    TotalCost = TotalInsurancePremium + HST
    # Get Monthly Payment Cost from Function.
    MonthlyPay = PayOption(Payment, TotalCost, DownPayment)
    # Get the Current Date.
    CurrentDate = datetime.now()
    # Calculate the First Payment date.
    PayDate = FirstDay(CurrentDate)


    # Display results.

    print()
    print()
    print()
    print(f" ----------------------------------------")
    print()
    print(f"        ONE STOP INSURANCE COMPANY")
    print()
    print(f" ----------------------------------------")
    print()
    print(f" Name:    {FirstName:<23s}")
    print(f"          {LastName:<23s}")
    print(f" Address: {Address:<23s}")
    print(f"          {City:<15s}, {Province:<2s}")
    print(f"          {PostalCode:>6s}")
    print(f" Phone:   {PhoneNum:>10s}")
    print()
    print(f" ----------------------------------------")
    print()
    print(f" Cars Being Insured:                   {NumCars:>2d}")
    # Processing for if Extra Liability Option is yes or no.
    if ExtraLiability == "Y":
        LiabilityOption = "YES"
    elif ExtraLiability == "N":
        LiabilityOption = "NO"
    print(f" Extra Liability:                     {LiabilityOption:>3s}")
    # Processing for if Glass Coverage Option is yes or no.
    if GlassCoverage == "Y":
        GlassOption = "YES"
    elif GlassCoverage == "N":
        GlassOption = "NO"
    print(f" Glass Coverage:                      {GlassOption:>3s}")
    # Processing for if Loaner Car Option is yes or no.
    if LoanerCar == "Y":
        LoanerOption = "YES"
    elif LoanerCar == "N":
        LoanerOption = "NO"
    print(f" Loaner Car:                          {LoanerOption:>3s}")
    print()
    # Processing for Payment Option display.
    if Payment == "Full":
        PayDisplay = "Full"
    elif Payment == "Monthly":
        PayDisplay = "Monthly"
    elif Payment == "Down Pay":
        PayDisplay = "Down Pay"
    print(f" Payment Type:                   {PayDisplay:>8s}")
    if Payment == "Down Pay":
        print()
        print(f" Down Payment Amount:          {FV.FDollar2(DownPayment):>10s}")
    print()
    print(f" ----------------------------------------")
    print()

    # Format Insurance Premium Cost.
    print(f" Insurance Premium:            {FV.FDollar2(InsurancePrem):>10s}")
    # Format Total Extra Costs.
    print(f" Total Extra Costs:            {FV.FDollar2(TotalExtra):>10s}")
    # Format Total Insurance Premium Cost.
    print(f" Total Insurance Premium:      {FV.FDollar2(TotalInsurancePremium):>10s}")
    # Format HST Cost.
    print(f" HST:                          {FV.FDollar2(HST):>10s}")
    print()
    # Process and Format Payment Option for Total Cost.
    if Payment == "Full":
        print(f" Total Cost:                   {FV.FDollar2(TotalCost):>10s}")
    else:
        print(f" Monthly Cost:                 {FV.FDollar2(MonthlyPay):>10s}")
        print(f" (8 Monthly Payments)")
    print()
    print(f" ----------------------------------------")
    print()
    # Format Current Date.
    print(f" Invoice Date:                 {FV.FDateS(CurrentDate):>10s}")
    # Format First Payment Date.
    print(f" First Payment Date:           {FV.FDateS(PayDate):>10s}")
    print()
    print(f" ----------------------------------------")
    print()
    print(f" Previous Claims:")
    print()
    print(f" Claim #     Claim Date            Amount")
    print(f" ----------------------------------------")
    # Display and Format the Claim Number, Claim Date, and Claim Amount Lists.
    for ClaimNum, ClaimDate, ClaimAmt in zip(CLAIM_NUM_LST, CLAIM_DATE_LST, CLAIM_AMT_LST):
        print(f"  {ClaimNum:>5d}      {FV.FDateS(ClaimDate):<10s}        {FV.FDollar2(ClaimAmt):>10s}")
    print(f" ----------------------------------------")
    print()
    print()


    # End Option and Validations for the Program Loop
    RepeatLoop = input("Enter Another Customer? (Y/N): ").upper()

    # Loop until the input is valid
    while RepeatLoop not in OPTION_LST:
        if RepeatLoop == "":
            print()
            print("   Data Entry Error - Option must be entered...")
            print()
        else:
            print()
            print("   Data Entry Error - Option entered is invalid. Must be Y or N...")
            print()
        RepeatLoop = input("Enter Another Customer? (Y/N): ").upper()

    # Process valid input
    if RepeatLoop == "N":
        print()
        print("   Exiting the Program! Goodbye!")
        print()
        break  # Exit the program
    elif RepeatLoop == "Y":
        print()
        print("   Restarting the program...")
        print()
        # Restart the loop for repeating the program
        continue  # Go back to the start of the program loop

